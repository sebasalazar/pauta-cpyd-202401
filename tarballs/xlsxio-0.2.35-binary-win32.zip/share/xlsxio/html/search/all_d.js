var searchData=
[
  ['to_20an_20xlsx_20file_0',['To an xlsx file',['../index.html#autotoc_md10',1,'Writing to an .xlsx file'],['../Z:/xlsxio/README.md#autotoc_md22',1,'Writing to an .xlsx file']]]
];
