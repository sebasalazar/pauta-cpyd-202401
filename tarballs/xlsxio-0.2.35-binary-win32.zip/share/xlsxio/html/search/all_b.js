var searchData=
[
  ['reading_20from_20an_20xlsx_20file_0',['Reading from an xlsx file',['../index.html#autotoc_md8',1,'Reading from an .xlsx file'],['../Z:/xlsxio/README.md#autotoc_md20',1,'Reading from an .xlsx file']]]
];
