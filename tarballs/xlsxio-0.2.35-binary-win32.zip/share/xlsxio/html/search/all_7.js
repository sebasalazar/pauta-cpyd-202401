var searchData=
[
  ['i_20o_0',['XLSX I/O',['../index.html',1,'']]],
  ['in_20an_20xlsx_20file_1',['In an xlsx file',['../index.html#autotoc_md9',1,'Listing all worksheets in an .xlsx file'],['../Z:/xlsxio/README.md#autotoc_md21',1,'Listing all worksheets in an .xlsx file']]]
];
