var searchData=
[
  ['utilities_0',['Utilities',['../index.html#autotoc_md3',1,'Command line utilities'],['../Z:/xlsxio/README.md#autotoc_md15',1,'Command line utilities']]]
];
