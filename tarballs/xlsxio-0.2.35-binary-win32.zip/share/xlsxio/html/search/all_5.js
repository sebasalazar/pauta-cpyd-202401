var searchData=
[
  ['file_0',['File',['../index.html#autotoc_md9',1,'Listing all worksheets in an .xlsx file'],['../Z:/xlsxio/README.md#autotoc_md21',1,'Listing all worksheets in an .xlsx file'],['../index.html#autotoc_md8',1,'Reading from an .xlsx file'],['../Z:/xlsxio/README.md#autotoc_md20',1,'Reading from an .xlsx file'],['../index.html#autotoc_md10',1,'Writing to an .xlsx file'],['../Z:/xlsxio/README.md#autotoc_md22',1,'Writing to an .xlsx file']]],
  ['from_20an_20xlsx_20file_1',['From an xlsx file',['../index.html#autotoc_md8',1,'Reading from an .xlsx file'],['../Z:/xlsxio/README.md#autotoc_md20',1,'Reading from an .xlsx file']]],
  ['from_20source_2',['From source',['../index.html#autotoc_md5',1,'Building from source'],['../Z:/xlsxio/README.md#autotoc_md17',1,'Building from source']]]
];
