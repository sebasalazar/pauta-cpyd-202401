var searchData=
[
  ['dependencies_0',['Dependencies',['../index.html#autotoc_md4',1,'Dependencies'],['../Z:/xlsxio/README.md#autotoc_md16',1,'Dependencies']]],
  ['description_1',['Description',['../index.html#autotoc_md0',1,'Description'],['../Z:/xlsxio/README.md#autotoc_md12',1,'Description']]]
];
