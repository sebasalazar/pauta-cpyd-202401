var searchData=
[
  ['goal_0',['Goal',['../index.html#autotoc_md1',1,'Goal'],['../Z:/xlsxio/README.md#autotoc_md13',1,'Goal']]]
];
