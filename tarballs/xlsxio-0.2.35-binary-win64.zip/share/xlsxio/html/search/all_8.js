var searchData=
[
  ['libraries_0',['Libraries',['../index.html#autotoc_md2',1,'Libraries'],['../Z:/xlsxio/README.md#autotoc_md14',1,'Libraries']]],
  ['license_1',['License',['../index.html#autotoc_md11',1,'License'],['../Z:/xlsxio/README.md#autotoc_md23',1,'License']]],
  ['line_20utilities_2',['Line utilities',['../index.html#autotoc_md3',1,'Command line utilities'],['../Z:/xlsxio/README.md#autotoc_md15',1,'Command line utilities']]],
  ['listing_20all_20worksheets_20in_20an_20xlsx_20file_3',['Listing all worksheets in an xlsx file',['../index.html#autotoc_md9',1,'Listing all worksheets in an .xlsx file'],['../Z:/xlsxio/README.md#autotoc_md21',1,'Listing all worksheets in an .xlsx file']]]
];
