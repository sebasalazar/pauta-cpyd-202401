var searchData=
[
  ['binaries_0',['Binaries',['../index.html#autotoc_md6',1,'Prebuilt binaries'],['../Z:/xlsxio/README.md#autotoc_md18',1,'Prebuilt binaries']]],
  ['building_20from_20source_1',['Building from source',['../index.html#autotoc_md5',1,'Building from source'],['../Z:/xlsxio/README.md#autotoc_md17',1,'Building from source']]]
];
