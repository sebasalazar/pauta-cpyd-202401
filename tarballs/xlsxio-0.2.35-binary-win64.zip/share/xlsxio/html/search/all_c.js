var searchData=
[
  ['shared_5fstrings_5fcallback_5fdata_0',['shared_strings_callback_data',['../structshared__strings__callback__data.html',1,'']]],
  ['sharedstringlist_1',['sharedstringlist',['../structsharedstringlist.html',1,'']]],
  ['source_2',['Source',['../index.html#autotoc_md5',1,'Building from source'],['../Z:/xlsxio/README.md#autotoc_md17',1,'Building from source']]]
];
