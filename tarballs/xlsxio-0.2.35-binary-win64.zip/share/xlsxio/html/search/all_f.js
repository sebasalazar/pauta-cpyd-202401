var searchData=
[
  ['worksheets_20in_20an_20xlsx_20file_0',['Worksheets in an xlsx file',['../index.html#autotoc_md9',1,'Listing all worksheets in an .xlsx file'],['../Z:/xlsxio/README.md#autotoc_md21',1,'Listing all worksheets in an .xlsx file']]],
  ['writing_20to_20an_20xlsx_20file_1',['Writing to an xlsx file',['../index.html#autotoc_md10',1,'Writing to an .xlsx file'],['../Z:/xlsxio/README.md#autotoc_md22',1,'Writing to an .xlsx file']]]
];
