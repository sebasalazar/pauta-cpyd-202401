var indexSectionsWithContent =
{
  0: "abcdefgiloprstuwx",
  1: "s",
  2: "x",
  3: "x",
  4: "x",
  5: "x",
  6: "iox"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "typedefs",
  5: "defines",
  6: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Files",
  3: "Functions",
  4: "Typedefs",
  5: "Macros",
  6: "Pages"
};

