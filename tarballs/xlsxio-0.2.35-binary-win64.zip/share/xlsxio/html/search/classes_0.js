var searchData=
[
  ['shared_5fstrings_5fcallback_5fdata_0',['shared_strings_callback_data',['../structshared__strings__callback__data.html',1,'']]],
  ['sharedstringlist_1',['sharedstringlist',['../structsharedstringlist.html',1,'']]]
];
