var searchData=
[
  ['prebuilt_20binaries_0',['Prebuilt binaries',['../index.html#autotoc_md6',1,'Prebuilt binaries'],['../Z:/xlsxio/README.md#autotoc_md18',1,'Prebuilt binaries']]],
  ['programs_1',['Programs',['../index.html#autotoc_md7',1,'Example C programs'],['../Z:/xlsxio/README.md#autotoc_md19',1,'Example C programs']]]
];
